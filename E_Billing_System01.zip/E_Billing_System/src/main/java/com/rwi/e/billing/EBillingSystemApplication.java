package com.rwi.e.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBillingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBillingSystemApplication.class, args);
	}

}
