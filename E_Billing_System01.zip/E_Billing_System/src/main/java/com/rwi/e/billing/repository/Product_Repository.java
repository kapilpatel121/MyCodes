package com.rwi.e.billing.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rwi.e.billing.Entity.Product_Entity;

public interface Product_Repository extends JpaRepository<Product_Entity, Integer>{
	Optional<Product_Entity> findById(int Id);
	@Query(value = "SELECT name FROM Product_Details", nativeQuery = true)
	List<String> getProductNames();

	

}
