package com.rwi.e.billing.Service;

import java.util.List;

import com.rwi.e.billing.dto.Customer;

public interface IBillingService {

	public void SaveBillInfo(Customer cust);
	
}
