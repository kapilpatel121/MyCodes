package com.rwi.e.billing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBillingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
